package automotiveRepairShop;

public class Vehicle implements Comparable<Vehicle> {
    private String VIN;

    private int mileage;

    private String damage;


    public int getMileage() {
        return mileage;
    }

    public String getVIN() {
        return VIN;
    }


    public Vehicle(String VIN , int mileage , String damage){
        this.VIN = VIN;
        this.mileage = mileage;
        this.damage = damage;
    }


    @Override
    public String toString() {
        return String.format("Damage: %s, Vehicle: %s (%d km)",damage,VIN,mileage);
    }


    @Override
    public int compareTo(Vehicle o) {
        return 0;
    }
}
