package automotiveRepairShop;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class RepairShop {

    private int capacity;
    private List<Vehicle> vehicles;


    public RepairShop(int capacity){

        this.capacity = capacity;
        vehicles = new ArrayList<>();

    }

    public void addVehicle(Vehicle vehicle){
        if(vehicles.size() < capacity){
            vehicles.add(vehicle);
        }
    }

    public boolean removeVehicle(String vin){
        for(Vehicle car :vehicles){
            if(car.getVIN().equals(vin)){
                vehicles.remove(car);
                return true;
            }
        }
        return false;
    }

    public int getCount(){
        return vehicles.size();
    }

    public Vehicle getLowestMileage(){
        Vehicle carWithLowestMiles = vehicles.get(0);
       for(Vehicle cars : vehicles){
           if(cars.getMileage() < carWithLowestMiles.getMileage()){
               carWithLowestMiles = cars;
           }

       }
       return carWithLowestMiles;
    }

    public String report(){
        StringBuilder sb = new StringBuilder();
        sb.append("Vehicles in the preparatory:\n");
        for(Vehicle car : vehicles){
            sb.append(car.toString()+"\n");
        }

        return sb.toString();
    }
}
